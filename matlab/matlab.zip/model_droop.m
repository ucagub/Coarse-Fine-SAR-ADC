function model_droop = droop(i,c,hold_time)
    model_droop = hold_time*i/c;
end
